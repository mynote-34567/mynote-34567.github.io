# 影城管理系统

本项目是一个计算机专业低年级学生Java课程项目的示例实现，旨在开发一个影城管理系统，针对一个具有5个放映厅、每个放映厅7排、每排12人的影城。

## 一、需求分析

### 1. 实体对象：

- 影城：包括放映厅、座位等。
- 放映厅：具有座位数、排数等属性。
- 用户：分为管理员、经理、前台和普通用户，拥有各自的权限和功能。
- 电影：包括片名、导演、主演、剧情简介、时长等信息。
- 场次：包括时间段、价格等信息。
- 座位：分为已订和空闲两种状态。
- 电影票：包括电子ID编号等信息。
- 参与者及对应的功能：

### 管理员：
- 登录
- 密码管理：修改自身密码，重置用户密码
- 用户管理：列出、删除、查询用户信息
- 退出登录

### 经理：
- 影片管理：列出、添加、修改、删除、查询影片信息
- 排片管理：增加、修改、删除、列出场次信息
- 登录
- 退出

### 前台：
- 登录
- 退出
- 列出正在上映影片和场次信息
- 列出指定电影和场次的座位信息
- 售票功能

### 用户：（顾客）
- 注册
- 登录：有账户锁定机制
- 密码管理：修改自身密码

## 二、逐步实现

### 1. 基于命令设计模式的交互式命令行界面

[v0.0.1 - action framework](https://github.com/thiswind/FilmHubTutorial/commit/210bc8da7b0d5fc93d4745b59ce4465f97e4dfef)


### 2. 基本的登录、注销

[v0.0.2 - basics login, logout](https://github.com/thiswind/FilmHubTutorial/commit/b9987cc2f2a49f8da1b639f5f5865134b19abbf9)


### 3. 增加数据库相关功能

- Database
- SQLite
- User
- DAO framework
- JUnit

[v0.0.3 - Database, SQLite, User, DAO framework, JUnit](https://github.com/thiswind/FilmHubTutorial/commit/a34996b062dfc069ac185b3ebfb2bd87219488bf)

### 4. 增加顾客注册相关功能

[v0.0.4 - Customer Register](https://github.com/thiswind/FilmHubTutorial/commit/614d9b90313e1da4d98223bc1849d40f63b977c5)

### 5. 增加User管理相关功能

[v0.0.5 - Add User operations](https://github.com/thiswind/FilmHubTutorial/commit/218207898d8e68ff0e800f2f64b53e4945e4e37e)