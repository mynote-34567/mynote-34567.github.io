package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.example.sqlite.SQLiteUserDAO;

public class Main {

    private List<AbstractAction> actions = null;
    private Scanner scanner = null;
    private GlobalState globalState = null;
    private UserService userService = null;

    private void printStatus(String msg, String status) {
        int totalLength = 80;
        int msgLength = msg.length();
        int statusLength = status.length();
        int dotsLength = totalLength - msgLength - statusLength - 4; // 4 = 2空格 + 2[]

        if (msgLength > 70 || statusLength > 70) {
            throw new IllegalArgumentException("msg or status length exceeds 70 characters");
        }

        StringBuilder sb = new StringBuilder();
        sb.append(msg);
        sb.append(" ");

        for (int i = 0; i < dotsLength; i++) {
            sb.append("·");
        }

        sb.append(" [");
        sb.append(status);
        sb.append("]");

        String result = sb.toString();
        System.out.println(result);
    }

    protected void initialize() {
        System.out.println("Initializing...");

        this.globalState = new GlobalState();
        this.actions = new ArrayList<>();
        this.scanner = new Scanner(System.in);
        this.printStatus("Initialize global variables", "OK");

        this.userService = new UserService(new SQLiteUserDAO());
        this.printStatus("Initialize Database", "OK");

        this.actions.add(new QuitAction(this.scanner, this.globalState));
        this.actions.add(new ListAction(this.actions));
        this.actions.add(new HelloworldAction(this.scanner));
        this.actions.add(new LoginAction(this.scanner, this.globalState, this.userService));
        this.actions.add(new LogoutAuthAction(this.globalState));
        this.printStatus("Install System Actions", "OK");

        this.actions.add(new ChangePasswordAction(this.userService, this.scanner, this.globalState));
        this.printStatus("Install User Actions", "OK");

        this.actions.add(new CustomerRegisterAction(this.userService, this.scanner));
        this.printStatus("Install Customer Actions", "OK");

        this.actions.add(new ListUserAction(this.userService));
        this.actions.add(new DeleteUserAction(this.userService, this.scanner));
        this.actions.add(new ChangeUserRoleAction(this.userService, this.scanner, this.globalState));
        this.printStatus("Install Administrator Actions", "OK");

        System.out.println("Initialization complete.");
    }

    protected void run() {
        System.out.println("Running...");

        System.out.println("Welcome to the application!");
        System.out.println("Type 'LIST' to list all available actions.");

        while (this.globalState.isRunning()) {
            String username = this.globalState.getUsername();
            username = username != null
                    ? "Logged in as: " + username.toLowerCase() + "@" + this.globalState.getRole().toString()
                    : "";
            System.out.print(username + "> ");
            String actionName = this.scanner.nextLine();

            boolean found = false;
            for (AbstractAction action : this.actions) {
                if (action.getActionName().equals(actionName)) {
                    action.run();
                    found = true;
                    break;
                }
            }

            if (!found) {
                System.out.println("Action not found.");
            }
        }

        System.out.println("Running complete.");
    }

    protected void free() {
        System.out.println("Freeing resources...");

        if (this.scanner != null) {
            this.scanner.close();
            this.printStatus("Close Scanner", "OK");
        }

        System.out.println("Resources freed.");
    }

    public static void main(String[] args) {
        Main app = new Main();
        app.initialize();
        try {
            app.run();
        } finally {
            app.free();
        }
    }
}
