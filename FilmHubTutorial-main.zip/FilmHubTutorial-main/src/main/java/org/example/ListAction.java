package org.example;

import java.util.List;

public class ListAction extends AbstractAction{

    private List<AbstractAction> list;

    public ListAction(List<AbstractAction> list) {
        this.list = list;
    }

    @Override
    public String getActionName() {
        return "LIST";
    }

    @Override
    public void run() {
        for (AbstractAction item : this.list) {
            String name = item.getActionName();
            String desc = item.getDesc();
            super.println(name + " - " + desc);
        }
    }
    
}
