package org.example;

public abstract class AbstractAuthenticatedAction extends AbstractAction {

    public enum Role {
        ADMINISTRATOR,
        MANAGER,
        RECEPTIONIST,
        CUSTOMER
    }

    protected static boolean isAuthenticated = false;
    protected static Role currentRole = null;

    protected void validate() throws AuthenticationException {
        if (!isAuthenticated) {
            throw new AuthenticationException("You must be authenticated to perform this action.");
        }
    }

    protected Role getCurrentRole() {
        return currentRole;
    }

    protected boolean getIsAuthenticated() {
        return isAuthenticated;
    }

    @Override
    public final void run() {
        try {
            validate();
            perform();
        } catch (AuthenticationException e) {
            println("Authentication failed: " + e.getMessage());
        }
    }

    protected abstract void perform();
}

class AuthenticationException extends Exception {
    public AuthenticationException(String message) {
        super(message);
    }
}