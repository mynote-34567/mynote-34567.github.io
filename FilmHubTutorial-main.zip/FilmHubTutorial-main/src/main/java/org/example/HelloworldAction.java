package org.example;

import java.util.Scanner;

public class HelloworldAction extends AbstractAction{

    private Scanner scanner;

    public HelloworldAction(Scanner scanner) {
        this.scanner = scanner;
    }

    @Override
    public String getActionName() {
        return "HELLO";
    }

    @Override
    public void run() {
        super.println("我怎么称呼你?");
        String nickname = scanner.nextLine();
        super.println("你好, " + nickname + "!");
    }
    
}
