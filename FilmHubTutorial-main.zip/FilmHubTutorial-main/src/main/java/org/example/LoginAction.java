package org.example;

import java.util.Scanner;

import org.example.AbstractAuthenticatedAction.Role;

public class LoginAction extends AbstractAction {

    private Scanner scanner = null;
    private GlobalState state = null;
    private UserService userService = null;

    public LoginAction(Scanner scanner, GlobalState state, UserService userService) {
        this.scanner = scanner;
        this.state = state;
        this.userService = userService;
    }

    @Override
    public String getActionName() {
        return "LOGIN";
    }

    @Override
    public void run() {
        super.print("Enter username: ");
        String username = scanner.nextLine();

        super.print("Enter password: ");
        String password = readPassword(this.scanner);

        Role role = login(username, password);
        if (role != null) {
            state.setUsername(username);
            state.setRole(role);
            state.setIsAuthenticated(true);
            super.println("Login successful.");
        } else {
            super.println("Login failed.");
        }
    }

    // Custom method to read password securely
    private static String readPassword(Scanner scanner) {
        // Turn off console echo
        System.out.print("\033[8m"); // This ANSI escape code hides input

        String input = scanner.nextLine();

        // Turn on console echo
        System.out.print("\033[0m"); // Reset ANSI escape codes

        return input;
    }

    private Role login(String username, String password) {
        if (username.equalsIgnoreCase("admin") && password.equals("ynuinfo#777")) {
            return Role.ADMINISTRATOR;
        }

        User user = this.userService.getUserByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            return user.getRole();
        }

        return null;
    }
}
