package org.example;

public class ListUserAction extends AbstractAuthenticatedAction{

    private UserService userService = null;

    public ListUserAction(UserService userService) {
        this.userService = userService;
    }


    @Override
    protected void perform() {
        Role currentRole = super.getCurrentRole();

        if (currentRole == Role.ADMINISTRATOR) {
            for (User user : userService.getAllUsers()) {
                String username = user.getUsername();
                Role role = user.getRole();
                super.println(username + "@" + role);
            }
        } else {
            super.println("You are not Administrator.");
        }
    }

    @Override
    public String getActionName() {
        return "LIST_USER";
    }
    
}
