package org.example;

import java.util.Scanner;

public class ChangePasswordAction extends AbstractAuthenticatedAction {

    private UserService userService = null;
    private Scanner scanner = null;
    private GlobalState globalState = null;

    public ChangePasswordAction(UserService userService, Scanner scanner, GlobalState globalState) {
        this.userService = userService;
        this.scanner = scanner;
        this.globalState = globalState;
    }

    @Override
    protected void perform() {
        Role currentRole = super.getCurrentRole();
        if (currentRole == Role.ADMINISTRATOR) {
            super.println(currentRole + " is not allowed to change password.");
        } else {

            String username = this.globalState.getUsername();
            User user = userService.getUserByUsername(username);
            super.print("Please enter new password: ");
            String newPassword = scanner.nextLine();
            user.setPassword(newPassword);
            userService.updateUser(user);
            super.println("Password of user " + username + " changed.");
        }
    }

    @Override
    public String getActionName() {
        return "CHANGE_PASSWORD";
    }

}
