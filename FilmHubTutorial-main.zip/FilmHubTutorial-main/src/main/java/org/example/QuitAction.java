package org.example;

import java.util.Scanner;

public class QuitAction extends AbstractAction {

    private Scanner scanner;
    private GlobalState globalState;

    public QuitAction(Scanner scanner, GlobalState globalState) {
        this.scanner = scanner;
        this.globalState = globalState;
    }

    @Override
    public String getActionName() {
        return "QUIT";
    }

    @Override
    public void run() {
        super.print("Are you sure to quit? (y/n) :");
        String answer = this.scanner.nextLine();
        if (answer.equals("y")) {
            globalState.setRunning(false);
        }
    }
    
}
