package org.example;

public class LogoutAuthAction extends AbstractAuthenticatedAction{

    private GlobalState state = null;

    public LogoutAuthAction(GlobalState state) {
        this.state = state;
    }

    @Override
    protected void perform() {
        state.setIsAuthenticated(false);
        state.setUsername(null);
        state.setRole(null);
        super.println("Logout successful.");
    }

    @Override
    public String getActionName() {
        return "LOGOUT";
    }
    
}
