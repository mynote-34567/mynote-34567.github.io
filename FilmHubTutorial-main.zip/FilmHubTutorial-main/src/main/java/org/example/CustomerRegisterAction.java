package org.example;

import java.util.Scanner;

import org.example.AbstractAuthenticatedAction.Role;

public class CustomerRegisterAction extends AbstractAction{

	private UserService userService = null;
	private Scanner scanner = null;

	public CustomerRegisterAction(UserService userService, Scanner scanner) {
		this.userService = userService;
		this.scanner = scanner;
	}

	@Override
	public String getActionName() {
		return "CUSTOMER_REGISTER";
	}

	@Override
	public void run() {
		super.println("顾客注册");

		super.print("用户名: ");
		String username = this.scanner.nextLine();

		super.print("密码: ");
		String password = this.scanner.nextLine();

		super.print("确认密码: ");
		String password2 = this.scanner.nextLine();

		if (!password.equals(password2)) {
			super.println("两次输入的密码不一致!");
			return;
		}

		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setRole(Role.CUSTOMER);

		boolean success = this.userService.addUser(user);

		if (success) {
			super.println("注册成功!");
		} else {
			super.println("注册失败!");
		}
	}
    
}
