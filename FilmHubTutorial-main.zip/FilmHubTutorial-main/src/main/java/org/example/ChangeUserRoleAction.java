package org.example;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ChangeUserRoleAction extends AbstractAuthenticatedAction {

    private UserService userService = null;
    private Scanner scanner = null;
    private GlobalState globalState = null;

    public ChangeUserRoleAction(UserService userService, Scanner scanner, GlobalState globalState) {
        this.userService = userService;
        this.scanner = scanner;
        this.globalState = globalState;
    }

    @Override
    protected void perform() {
        Role currentRole = this.globalState.getRole();

        if (currentRole != Role.ADMINISTRATOR) {
            super.println("You are not Administrator.");
        } else {
            super.print("Please input username of the user you want to change role: ");
            String username = scanner.nextLine();
            User user = userService.getUserByUsername(username);

            if (user == null) {
                super.println("User not found.");
            } else {
                Map<String, Role> roles = new HashMap<>();
                roles.put("1", Role.ADMINISTRATOR);
                roles.put("2", Role.MANAGER);
                roles.put("3", Role.CUSTOMER);

                super.println("Available roles: ");
                for(Map.Entry<String, Role> entry : roles.entrySet()) {
                    String roleNumber = entry.getKey();
                    String roleName = entry.getValue().toString();
                    super.println(roleNumber + ". " + roleName);
                }
                
                super.print("Please input the number of the role you want to change to: ");
                String roleNumber = scanner.nextLine();
                if (roles.containsKey(roleNumber)) {
                    user.setRole(roles.get(roleNumber));
                    userService.updateUser(user);
                    super.println("User role changed.");
                } else {
                    super.println("Invalid role number.");
                }
            }
        }
    }

    @Override
    public String getActionName() {
        return "CHANGE_USER_ROLE";
    }

}
