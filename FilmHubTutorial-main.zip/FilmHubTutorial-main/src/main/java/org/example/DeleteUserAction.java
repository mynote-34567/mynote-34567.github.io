package org.example;

import java.util.Scanner;

public class DeleteUserAction extends AbstractAuthenticatedAction{

    private UserService userService = null;
    private Scanner scanner = null;

    public DeleteUserAction(UserService userService, Scanner scanner) {
        this.userService = userService;
        this.scanner = scanner;
    }

	@Override
	protected void perform() {
		Role currentRole = super.getCurrentRole();

        if (currentRole == Role.ADMINISTRATOR) {
            super.print("Please enter username to delete: ");
            String username = scanner.nextLine();
            User user = userService.getUserByUsername(username);

            if (user == null) {
                super.println("User not found.");
            } else {
                super.print("Are you sure to delete user " + username + "? (y/n) ");
                String confirm = scanner.nextLine();
                if (confirm.equals("y")) {
                    userService.deleteUser(username);
                    super.println("User deleted.");
                } else {
                    super.println("Operation cancelled.");
                }
            }
        } else {
            super.println("You are not Administrator.");
        }
	}

	@Override
	public String getActionName() {
		return "DELETE_USER";
	}
    
}
